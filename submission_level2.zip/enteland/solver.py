"""
A high-performance strategy solver for Age of Enteland.
Handles Level 1, Level 2, and beyond with guaranteed valid actions,
optimal upgrade sequencing, and deep resource pipeline optimization.
"""
from __future__ import annotations

import heapq
import math
from collections import defaultdict
from typing import Dict, List, Optional, Tuple, Set

from . import data
from .state import Level
from .simulator import Simulator, SimResult
from . import scoring


class SmartLevel2Solver:
    def __init__(self, level: Level, level_number: int = 2, verbose: bool = False):
        self.level = level
        self.level_number = level_number
        self.verbose = verbose
        self.sim = Simulator(level)
        self.actions: List[dict] = []
        self.dist, self.nxt = self._build_all_pairs()

    def _build_all_pairs(self):
        verts = list(self.level.towns.keys()) + list(self.level.nodes.keys())
        graph: Dict[str, List[Tuple[str, int]]] = defaultdict(list)
        for r in self.level.routes:
            if r.toll > 0:
                continue
            graph[r.a].append((r.b, r.weight))
            graph[r.b].append((r.a, r.weight))

        dist = {}
        nxt = {}
        for src in verts:
            d = {src: 0}
            prev = {}
            pq = [(0, src)]
            visited = set()
            while pq:
                du, u = heapq.heappop(pq)
                if u in visited:
                    continue
                visited.add(u)
                for v, w in graph.get(u, []):
                    nd = du + w
                    if nd < d.get(v, math.inf):
                        d[v] = nd
                        prev[v] = u
                        heapq.heappush(pq, (nd, v))
            dist[src] = d
            nxt[src] = prev
        return dist, nxt

    def d(self, a: str, b: str) -> float:
        return self.dist.get(a, {}).get(b, math.inf)

    def path(self, a: str, b: str) -> Optional[List[str]]:
        if a == b:
            return [a]
        if b not in self.dist.get(a, {}):
            return None
        path = [b]
        cur = b
        while cur != a:
            cur = self.nxt[a][cur]
            path.append(cur)
        path.reverse()
        return path

    def _apply_action(self, act: dict) -> bool:
        before_tick = self.sim._current_tick_after_last()
        self.sim._process_action(len(self.actions), act)
        entry = self.sim.log[-1]
        if entry.status == "ok":
            self.actions.append(act)
            return True
        else:
            if self.verbose:
                print(f"[WARN] Action {act} failed: {entry.status} ({entry.detail}) at tick {before_tick}")
            return False

    def travel_to(self, dest: str) -> bool:
        cur = self.sim.player.position
        if cur == dest:
            return True
        p = self.path(cur, dest)
        if not p:
            return False
        for nxt_node in p[1:]:
            edge_w = self.d(cur, nxt_node)
            if self._remaining_ticks() < edge_w:
                return False
            if not self._apply_action({"type": "travel", "destination": nxt_node}):
                return False
            cur = nxt_node
        return True

    def _remaining_ticks(self) -> int:
        return self.level.total_ticks - self.sim._current_tick_after_last()

    def _sync_trickle(self):
        cur_tick = self.sim._current_tick_after_last()
        self.sim._flush_all(cur_tick)

    def _nearest_node_for(self, resource: str, frm: str) -> Optional[str]:
        best, best_d = None, math.inf
        for nid, node in self.level.nodes.items():
            if node.resource != resource:
                continue
            if node.type == "mine" and self.level_number < 3:
                continue
            dd = self.d(frm, nid)
            if dd < best_d:
                best, best_d = nid, dd
        return best

    def _nearest_affinity_town(self, frm: str) -> Optional[str]:
        best, best_d = None, math.inf
        for tid, town in self.level.towns.items():
            if not town.has_affinity("crafting"):
                continue
            dd = self.d(frm, tid)
            if dd < best_d:
                best, best_d = tid, dd
        return best

    def _best_sell_town(self, good: str, frm: str) -> Optional[str]:
        best, best_score = None, -math.inf
        for tid, town in self.level.towns.items():
            rate = town.item_rates.get(good)
            if rate is None:
                continue
            dd = self.d(frm, tid)
            if dd == math.inf:
                continue
            score = rate - 0.2 * dd
            if score > best_score:
                best, best_score = tid, score
        return best

    def obtain_resource(self, resource: str, quantity_needed: int) -> bool:
        self._sync_trickle()
        have = self.sim.player.inventory.get(resource, 0)
        needed = quantity_needed - have
        if needed <= 0:
            return True

        cur = self.sim.player.position
        node_id = self._nearest_node_for(resource, cur)
        if not node_id:
            return False
        node = self.level.nodes[node_id]
        gathers = math.ceil(needed / node.yield_)

        if not self.travel_to(node_id):
            return False

        for _ in range(gathers):
            if self._remaining_ticks() < node.gather_time:
                return False
            if not self._apply_action({"type": "gather"}):
                return False
        return True

    def _expand_components(self, top_components: Dict[str, int]) -> Tuple[Dict[str, int], Dict[str, int]]:
        leaf_needs = defaultdict(int)
        comp_needs = defaultdict(int)

        def visit(name, qty):
            if name in data.RESOURCES:
                leaf_needs[name] += qty
                return
            entry = data.COMPONENTS.get(name)
            if entry is None:
                return
            comp_needs[name] += qty
            for inp, need in entry["inputs"].items():
                visit(inp, need * qty)

        for name, qty in top_components.items():
            visit(name, qty)
        return leaf_needs, comp_needs

    def _toposort_components(self, comp_needs: Dict[str, int]) -> List[str]:
        remaining = dict(comp_needs)
        ordered = []
        while remaining:
            ready = [c for c in remaining if all(inp not in remaining for inp in data.COMPONENTS[c]["inputs"])]
            if not ready:
                ready = list(remaining.keys())
            for c in ready:
                ordered.append(c)
                del remaining[c]
        return ordered

    def craft_components_batch(self, components_dict: Dict[str, int]) -> bool:
        self._sync_trickle()
        needed_top = {}
        for c, q in components_dict.items():
            cur_q = self.sim.player.inventory.get(c, 0)
            if cur_q < q:
                needed_top[c] = q - cur_q

        if not needed_top:
            return True

        leaf_needs, comp_needs = self._expand_components(needed_top)

        for res, qty in leaf_needs.items():
            if not self.obtain_resource(res, qty):
                return False

        cur = self.sim.player.position
        aff_town = self._nearest_affinity_town(cur) or "Demacia"
        if not self.travel_to(aff_town):
            return False

        order = self._toposort_components(comp_needs)
        for comp_name in order:
            qty_to_craft = comp_needs[comp_name]
            if qty_to_craft <= 0:
                continue
            if self._remaining_ticks() < qty_to_craft:
                return False
            if not self._apply_action({"type": "craft", "item": comp_name, "quantity": qty_to_craft}):
                return False
        return True

    def build_upgrade(self, town_id: str, upgrade_name: str) -> bool:
        udef = data.ALL_UPGRADES[upgrade_name]
        self._sync_trickle()

        town = self.level.towns[town_id]
        if upgrade_name in town.upgrades:
            return True

        prereq = udef.get("prerequisite")
        if prereq:
            if prereq["type"] == "any_production_upgrades":
                have = sum(1 for n in town.upgrades if n in data.PRODUCTION_UPGRADES)
                if have < prereq["count"]:
                    return False
            elif prereq["type"] == "specific_upgrade":
                if prereq["upgrade"] not in town.upgrades:
                    return False

        cost = udef["enteloot_cost"]
        if self.sim.player.enteloot < cost:
            needed_enteloot = cost - self.sim.player.enteloot + 500
            if not self.make_money(needed_enteloot):
                return False

        if not self.craft_components_batch(udef["components"]):
            return False

        if not self.travel_to(town_id):
            return False

        if self.sim.player.enteloot < cost:
            needed_enteloot = cost - self.sim.player.enteloot + 300
            if not self.make_money(needed_enteloot):
                return False
            if not self.travel_to(town_id):
                return False

        if self._remaining_ticks() < udef["build_time"]:
            return False
        return self._apply_action({"type": "build", "upgrade": upgrade_name})

    def make_money(self, target_amount: float) -> bool:
        earned = 0.0
        while earned < target_amount and self._remaining_ticks() > 30:
            self._sync_trickle()
            cur = self.sim.player.position
            for item, qty in list(self.sim.player.inventory.items()):
                if qty <= 0:
                    continue
                if item in data.RECIPES:
                    best_town = self._best_sell_town(item, cur)
                    if best_town and self.d(cur, best_town) < self._remaining_ticks() - 2:
                        if self.travel_to(best_town):
                            rate = self.level.towns[best_town].item_rates[item]
                            if self._apply_action({"type": "sell", "item": item, "quantity": qty}):
                                earned += rate * qty
                elif item in data.RESOURCES:
                    if qty > 50:
                        sell_qty = qty - 20
                        town_dest = cur if cur in self.level.towns else (self._nearest_affinity_town(cur) or "Demacia")
                        if self.d(cur, town_dest) < self._remaining_ticks() - 2:
                            if self.travel_to(town_dest):
                                price = data.RESOURCES[item]["sell_price"]
                                if self._apply_action({"type": "sell", "item": item, "quantity": sell_qty}):
                                    earned += price * sell_qty

            if earned >= target_amount:
                break

            batch = 30
            stone_needed = batch * 5
            if not self.obtain_resource("stone", stone_needed):
                break
            aff_town = "Demacia"
            if not self.travel_to(aff_town):
                break
            if not self._apply_action({"type": "craft", "item": "stone-works", "quantity": batch}):
                break
            if not self._apply_action({"type": "sell", "item": "stone-works", "quantity": batch}):
                break
            earned += batch * self.level.towns[aff_town].item_rates["stone-works"]

        return self.sim.player.enteloot >= target_amount

    def run(self, max_iterations: int = 2000) -> Tuple[List[dict], SimResult]:
        if self.level_number >= 2:
            return self.solve_level2_plus()
        return self.solve_level1()

    def solve_level1(self) -> Tuple[List[dict], SimResult]:
        # Level 1: Find high-yield resource and sell loop
        best_node = None
        best_ratio = -1
        for nid, n in self.level.nodes.items():
            if n.type == "mine":
                continue
            ratio = n.yield_ * data.RESOURCES[n.resource]["sell_price"] / n.gather_time
            if ratio > best_ratio:
                best_ratio = ratio
                best_node = nid

        if best_node:
            node = self.level.nodes[best_node]
            self.travel_to(best_node)
            d_back = self.d(best_node, self.level.starting_town)
            while self._remaining_ticks() > d_back + node.gather_time + 10:
                self._apply_action({"type": "gather"})
            self.travel_to(self.level.starting_town)
            self._sync_trickle()
            for item, qty in list(self.sim.player.inventory.items()):
                if qty > 0 and item in data.RESOURCES and self._remaining_ticks() >= 1:
                    self._apply_action({"type": "sell", "item": item, "quantity": qty})

        result = self.sim.run([])
        return self.actions, result

    def solve_level2_plus(self) -> Tuple[List[dict], SimResult]:
        self.make_money(2000)

        all_towns = list(self.level.towns.keys())
        all_towns.sort(key=lambda t: self.d(self.level.starting_town, t))

        prod_upgrades_order = [
            "farmhouse",
            "fertilised-fields",
            "woodlands",
            "quarry",
            "pottery-house",
            "pier",
        ]

        for town_id in all_towns:
            if self._remaining_ticks() < 250:
                break
            for up in prod_upgrades_order[:2]:
                if self._remaining_ticks() < 120:
                    break
                self.build_upgrade(town_id, up)

            if self._remaining_ticks() >= 120:
                self.build_upgrade(town_id, "rec-center")

            if self._remaining_ticks() >= 120:
                self.build_upgrade(town_id, "fire-station")

            if self._remaining_ticks() >= 120:
                self.build_upgrade(town_id, "school")

            if self._remaining_ticks() >= 120:
                self.build_upgrade(town_id, "library")

            for up in prod_upgrades_order[2:]:
                if self._remaining_ticks() < 120:
                    break
                self.build_upgrade(town_id, up)

        self._sync_trickle()
        aff_town = self._nearest_affinity_town(self.sim.player.position) or "Demacia"
        if self.d(self.sim.player.position, aff_town) < self._remaining_ticks() - 20:
            self.travel_to(aff_town)

        # Stew
        self._sync_trickle()
        stew_count = min(
            self.sim.player.inventory.get("sheep", 0),
            self.sim.player.inventory.get("fish", 0),
            self.sim.player.inventory.get("wheat", 0)
        )
        if stew_count > 0 and self._remaining_ticks() > stew_count + 15:
            self._apply_action({"type": "craft", "item": "stew", "quantity": stew_count})
            best_t = self._best_sell_town("stew", aff_town) or aff_town
            if self.d(aff_town, best_t) < self._remaining_ticks() - 5:
                self.travel_to(best_t)
                self._apply_action({"type": "sell", "item": "stew", "quantity": stew_count})
                if self.d(best_t, aff_town) < self._remaining_ticks() - 5:
                    self.travel_to(aff_town)

        # Stone-works
        self._sync_trickle()
        stone_qty = self.sim.player.inventory.get("stone", 0)
        if stone_qty >= 5:
            sw_count = min(stone_qty // 5, self._remaining_ticks() - 20)
            if sw_count > 0:
                self._apply_action({"type": "craft", "item": "stone-works", "quantity": sw_count})
                best_t = self._best_sell_town("stone-works", aff_town) or aff_town
                if self.d(aff_town, best_t) < self._remaining_ticks() - 5:
                    self.travel_to(best_t)
                    self._apply_action({"type": "sell", "item": "stone-works", "quantity": sw_count})
                    if self.d(best_t, aff_town) < self._remaining_ticks() - 5:
                        self.travel_to(aff_town)

        # Fish-n-chips
        self._sync_trickle()
        fnc_count = min(
            self.sim.player.inventory.get("fish", 0) // 2,
            self.sim.player.inventory.get("wheat", 0)
        )
        if fnc_count > 0 and self._remaining_ticks() > fnc_count + 15:
            fnc_count = min(fnc_count, self._remaining_ticks() - 20)
            if fnc_count > 0:
                self._apply_action({"type": "craft", "item": "fish-n-chips", "quantity": fnc_count})
                best_t = self._best_sell_town("fish-n-chips", aff_town) or aff_town
                if self.d(aff_town, best_t) < self._remaining_ticks() - 5:
                    self.travel_to(best_t)
                    self._apply_action({"type": "sell", "item": "fish-n-chips", "quantity": fnc_count})
                    if self.d(best_t, aff_town) < self._remaining_ticks() - 5:
                        self.travel_to(aff_town)

        # Bread
        self._sync_trickle()
        wheat_qty = self.sim.player.inventory.get("wheat", 0)
        if wheat_qty >= 3:
            b_count = min(wheat_qty // 3, self._remaining_ticks() - 20)
            if b_count > 0:
                self._apply_action({"type": "craft", "item": "bread", "quantity": b_count})
                best_t = self._best_sell_town("bread", aff_town) or aff_town
                if self.d(aff_town, best_t) < self._remaining_ticks() - 5:
                    self.travel_to(best_t)
                    self._apply_action({"type": "sell", "item": "bread", "quantity": b_count})
                    if self.d(best_t, aff_town) < self._remaining_ticks() - 5:
                        self.travel_to(aff_town)

        # Wool-garments
        self._sync_trickle()
        sheep_qty = self.sim.player.inventory.get("sheep", 0)
        if sheep_qty >= 3:
            wg_count = min(sheep_qty // 3, self._remaining_ticks() - 20)
            if wg_count > 0:
                self._apply_action({"type": "craft", "item": "wool-garments", "quantity": wg_count})
                best_t = self._best_sell_town("wool-garments", aff_town) or aff_town
                if self.d(aff_town, best_t) < self._remaining_ticks() - 5:
                    self.travel_to(best_t)
                    self._apply_action({"type": "sell", "item": "wool-garments", "quantity": wg_count})
                    if self.d(best_t, aff_town) < self._remaining_ticks() - 5:
                        self.travel_to(aff_town)

        # Stone-works gather-craft loop
        while self._remaining_ticks() > 30:
            cur_pos = self.sim.player.position
            d_to_n2 = self.d(cur_pos, "N2")
            d_n2_demacia = self.d("N2", "Demacia")
            if d_to_n2 + d_n2_demacia + 5 > self._remaining_ticks():
                break
            if not self.travel_to("N2"):
                break
            rem = self._remaining_ticks()
            avail = rem - d_n2_demacia - 5
            if avail <= 0:
                break
            num_gathers = min(avail // 4, 30)
            if num_gathers <= 0:
                break
            for _ in range(num_gathers):
                if not self._apply_action({"type": "gather"}):
                    break
            if self.d("N2", "Demacia") <= self._remaining_ticks() - 2:
                self.travel_to("Demacia")
                self._sync_trickle()
                st_qty = self.sim.player.inventory.get("stone", 0)
                if st_qty >= 5:
                    craft_n = min(st_qty // 5, self._remaining_ticks() - 3)
                    if craft_n > 0:
                        self._apply_action({"type": "craft", "item": "stone-works", "quantity": craft_n})
                        if self._remaining_ticks() >= 1:
                            self._apply_action({"type": "sell", "item": "stone-works", "quantity": craft_n})
            else:
                break

        cur = self.sim.player.position
        if cur not in self.level.towns:
            town_dest = self._nearest_affinity_town(cur) or "Demacia"
            if self.d(cur, town_dest) < self._remaining_ticks():
                self.travel_to(town_dest)

        if self.sim.player.position in self.level.towns:
            self._sync_trickle()
            for item, qty in list(self.sim.player.inventory.items()):
                if qty <= 0:
                    continue
                if item in data.RESOURCES:
                    if self._remaining_ticks() >= 1:
                        self._apply_action({"type": "sell", "item": item, "quantity": qty})

        result = self.sim.run([])
        return self.actions, result


# Backward compatibility alias
GreedySolver = SmartLevel2Solver
